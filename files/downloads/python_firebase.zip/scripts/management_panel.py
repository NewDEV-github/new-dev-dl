import firebase_admin
from firebase_admin import credentials
from firebase_admin import auth
from firebase_admin import db
import PyQt5
import os
import sys
from PyQt5 import QtCore
from PyQt5.QtCore import Qt
from PyQt5.QtGui import QIcon
from PyQt5.QtWidgets import QLineEdit, QMessageBox, QPushButton, QHBoxLayout, QVBoxLayout, QLabel, QGridLayout, QApplication, QWidget
uid = sys.argv[1]

##initialize variables
print("Re-initializing Firebase for Database usage...")
cred = credentials.Certificate("data/api-9176249411662404922-339889-firebase-adminsdk-kxg6h-9f87587e71.json")
##code
firebase_admin.initialize_app(cred, {
    'databaseURL': 'https://api-9176249411662404922-339889.firebaseio.com'
})
print("Re-initialized successfully!")


class FirebasePythonApp(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.interface()
    def del_account(self):
        pass
    def render_user_data(self):
        self.ref = db.reference('users/' + uid)
        print(self.ref.get())
    def interface(self):
        self.render_user_data()
        self.gui = QVBoxLayout()
        self.info_label = QLabel("Create an account to get started\nWARNING: Logging into existing accounts is currently UNSUPPORTED", self)
        #self.register_btn = QPushButton("&Delete account", self)
        self.gui.addWidget(self.info_label)
        #self.gui.addWidget(self.register_btn)
        self.info_label.setText("Email: " + self.ref.get()['email'] + "\nUsername: " + self.ref.get()['username'] + "\n\nLink to Your profile: https://www.new-dev.ml/profile?uid=" + uid)
        #self.register_btn.clicked.connect(self.del_account)
        self.setLayout(self.gui)
        self.info_label.setTextInteractionFlags(QtCore.Qt.TextInteractionFlag.TextSelectableByMouse)
        self.setWindowIcon(QIcon('icons/icon.png'))
        self.resize(300, 100)
        self.setWindowTitle("Firebase Python App")
        self.show()
    def keyPressEvent(self, e):
        if e.key() == Qt.Key_Escape:
            self.close()
    def closeEvent(self, event):
        odp = QMessageBox.question(
            self, 'Komunikat',
            "Czy na pewno koniec?",
            QMessageBox.Yes | QMessageBox.No, QMessageBox.No)
        if odp == QMessageBox.Yes:
            event.accept()
        else:
            event.ignore()

    

if __name__ == '__main__':
    import sys

    app = QApplication(sys.argv)
    window = FirebasePythonApp()
    sys.exit(app.exec_())

import firebase_admin
from firebase_admin import credentials
from firebase_admin import auth
import PyQt5
import subprocess
from PyQt5.QtCore import Qt
from firebase_admin import db
from PyQt5.QtGui import QIcon
from PyQt5.QtWidgets import QLineEdit, QMessageBox, QPushButton, QHBoxLayout, QVBoxLayout, QLabel, QGridLayout, QApplication, QWidget
##define functions
def create_account(e, p, dn):
    user = auth.create_user(
        email=str(e),
        email_verified=False,
        password=str(p),
        display_name=str(dn))
    print('Sucessfully created new user: {0}'.format(user.uid))
    ref = db.reference('users/{0}'.format(user.uid))
    ref.set({'email': e, 'username': dn})
    #print("Verification email link: " + auth.generate_email_verification_link(e))
    subprocess.Popen(["python", "scripts/management_panel.py", "{0}".format(user.uid)])

##initialize variables
user = ""
print("Initializing Firebase...")
cred = credentials.Certificate("data/api-9176249411662404922-339889-firebase-adminsdk-kxg6h-9f87587e71.json")
##code
firebase_admin.initialize_app(cred, {
    'databaseURL': 'https://api-9176249411662404922-339889.firebaseio.com'
})
print("Initialized successfully!")



class FirebasePythonApp(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.interface()
    def begin_account_creation(self):
        create_account(self.email_edt.text(), self.pass_edt.text(), self.nick_edt.text())
        exit()
    def interface(self):
        self.gui = QGridLayout()
        self.pass_edt = QLineEdit()
        self.email_edt = QLineEdit()
        self.nick_edt = QLineEdit()
        self.info_label = QLabel("Create an account to get started\nWARNING: Logging into existing accounts is currently UNSUPPORTED", self)
        self.pass_label = QLabel("Password: ", self)
        self.email_label = QLabel("Email: ", self)
        self.nick_label = QLabel("Nickname: ", self)
        self.register_btn = QPushButton("&Create account", self)
        self.gui.addWidget(self.info_label)
        self.gui.addWidget(self.email_label)
        self.gui.addWidget(self.email_edt)
        self.gui.addWidget(self.pass_label)
        self.gui.addWidget(self.pass_edt)
        self.gui.addWidget(self.nick_label)
        self.gui.addWidget(self.nick_edt)
        self.gui.addWidget(self.register_btn)
        self.register_btn.clicked.connect(self.begin_account_creation)
        self.setLayout(self.gui)
        self.setWindowIcon(QIcon('icons/icon.png'))
        self.resize(300, 100)
        self.setWindowTitle("Firebase Python App")
        self.show()
    def keyPressEvent(self, e):
        if e.key() == Qt.Key_Escape:
            self.close()
    def closeEvent(self, event):
        odp = QMessageBox.question(
            self, 'Komunikat',
            "Czy na pewno koniec?",
            QMessageBox.Yes | QMessageBox.No, QMessageBox.No)
        if odp == QMessageBox.Yes:
            event.accept()
        else:
            event.ignore()
    

if __name__ == '__main__':
    import sys

    app = QApplication(sys.argv)
    window = FirebasePythonApp()
    sys.exit(app.exec_())

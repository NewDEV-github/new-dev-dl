import os
os.system("python scripts/create_account_panel.py")
exit()